export default function WaveDivider() {
  return <div className="wave-divider" data-testid="wave-divider"></div>;
}